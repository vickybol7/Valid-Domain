import re
import dns.resolver
import smtplib
import concurrent.futures
from time import sleep

# Email validation functions
def is_valid_email_format(email):
    regex = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    
    if not isinstance(email, str) or not email:
        return False

    return re.match(regex, email) is not None

def has_mx_record(domain):
    try:
        mx_records = dns.resolver.resolve(domain, 'MX')
        return len(mx_records) > 0
    except:
        return False

def verify_email_smtp(email):
    try:
        domain = email.split('@')[1]
        mx_records = dns.resolver.resolve(domain, 'MX')
        mx_host = str(mx_records[0].exchange)

        server = smtplib.SMTP(timeout=10)
        server.connect(mx_host)
        server.helo('example.com')
        server.mail('test@example.com')
        code, message = server.rcpt(email)
        server.quit()

        return code == 250
    except Exception as e:
        print("SMTP Check Error:", e)
        return False

# Function to check a single email and save valid ones to the file
def check_and_save_email(email, output_file):
    if not email:
        return

    # Check email validity
    if not is_valid_email_format(email):
        return

    domain = email.split('@')[1].lower()

    # Check MX record
    if not has_mx_record(domain):
        return

    # Check via SMTP
    if not verify_email_smtp(email):
        return

    # If all checks pass, save valid email to file immediately
    with open(output_file, 'a') as output:
        output.write(email + '\n')
    
    print(f"Valid email found: {email}")

    # Sleep to avoid overloading servers
    sleep(2)

# Function to read emails from a text file and check them in parallel using threads
def test_emails_from_file(file_path, output_file):
    with open(file_path, 'r') as file:
        emails = [line.strip() for line in file.readlines()]

    # Use ThreadPoolExecutor to process emails in parallel
    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = []
        for email in emails:
            futures.append(executor.submit(check_and_save_email, email, output_file))

        # Wait for all threads to complete
        concurrent.futures.wait(futures)

    print(f"Valid emails have been saved to {output_file}")

# Test the emails in 'emails.txt' and save valid ones to 'valid_emails.txt'
test_emails_from_file('emails.txt', 'valid_emails.txt')

